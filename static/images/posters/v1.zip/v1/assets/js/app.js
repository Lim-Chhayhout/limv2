(() =>{
    document.querySelectorAll('.nav-section').forEach(item => {
        item.addEventListener('click', () => {
            const target = document.querySelector('.' + item.dataset.target);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
})();

(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const openBtn = document.querySelector(".btn-contact-by-email");
        const popup = document.querySelector(".pop-up");
        const closeBtn = document.querySelector(".back-from-keep-in");

        if (!openBtn || !popup || !closeBtn) return;

        openBtn.addEventListener("click", () => {
            popup.classList.add("active");
            document.body.classList.add("no-scroll");
        });

        closeBtn.addEventListener("click", () => {
            popup.classList.remove("active");
            document.body.classList.remove("no-scroll");
        });
    });
})();


(() =>{
    document.querySelectorAll('.home').forEach(home => {
        const letterHome = "ABCDEFGHIJKLMNOPRSTUVWXYZ";
        const letterHomeEls = home.querySelectorAll(".letter");

        const textHome = ["LIM CHHAYHOUT", "WEB DEVELOPMENT"];
        let currentIndex = 0;

        const totalHomeLetters = letterHomeEls.length;

        function scrambleToText(textHome, speed = 25, delay = 25) {
            const padded = textHome.padEnd(totalHomeLetters, " ");

            for (let i = 0; i < totalHomeLetters; i++) {
                let scramble = setInterval(() => {
                    letterHomeEls[i].textContent = letterHome[Math.floor(Math.random() * letterHome.length)];
                }, speed);

                setTimeout(() => {
                    clearInterval(scramble);
                    letterHomeEls[i].textContent = padded[i];
                }, delay * (i + 1));
            }
        }

        function loop() {
            scrambleToText(textHome[currentIndex]);
            setTimeout(() => {
                currentIndex = (currentIndex + 1) % textHome.length;
                loop();
            }, 5000);
        }
        loop();
    });

    document.querySelectorAll('.sub-about').forEach(home => {
        const letterHome = "ABCDEFGHIJKLMNOPRSTUVWXYZ";
        const letterHomeEls = home.querySelectorAll(".letter");

        const textHome = ["ABOUT ME", "ABOUT SKILLS"];
        let currentIndex = 0;

        const totalHomeLetters = letterHomeEls.length;

        function scrambleToText(textHome, speed = 25, delay = 25) {
            const padded = textHome.padEnd(totalHomeLetters, " ");

            for (let i = 0; i < totalHomeLetters; i++) {
                let scramble = setInterval(() => {
                    letterHomeEls[i].textContent = letterHome[Math.floor(Math.random() * letterHome.length)];
                }, speed);

                setTimeout(() => {
                    clearInterval(scramble);
                    letterHomeEls[i].textContent = padded[i];
                }, delay * (i + 1));
            }
        }

        function loop() {
            scrambleToText(textHome[currentIndex]);
            setTimeout(() => {
                currentIndex = (currentIndex + 1) % textHome.length;
                loop();
            }, 5000);
        }
        loop();
    });

})();

(() => {
    const openBtn = document.getElementById('sub-about-button');
    const closeBtn = document.getElementById('sub-about-close');
    const panel = document.querySelector('.sub-about-content');
    const background = panel.querySelector('.background');

    let open = false;

    const openPanel = () => {
        open = true;
        panel.style.display = 'flex';
        lockScroll();
        requestAnimationFrame(() => panel.classList.add('open'));
        background.style.opacity = '1';
    };

    const closePanel = () => {
        if (!open) return;
        open = false;
        panel.classList.remove('open');
        background.style.opacity = '0';
        unlockScroll();
        panel.addEventListener('transitionend', () => {
            panel.style.display = 'none';
        }, { once: true });
    };

    openBtn.addEventListener('click', e => {
        e.stopPropagation();
        open ? closePanel() : openPanel();
    });

    closeBtn.addEventListener('click', e => {
        e.stopPropagation();
        closePanel();
    });

    background.addEventListener('click', closePanel);

    function lockScroll() {
        document.body.style.overflow = 'hidden';
    }

    function unlockScroll() {
        document.body.style.overflow = '';
    }
})();

(() => {
    const form = document.querySelector(".mail form");
    const response = document.querySelector(".reponse");
    const okBtn = document.querySelector(".okay-with-reponse");

    if (!form || !response || !okBtn) return;

    form.addEventListener("submit", e => {
        e.preventDefault();

        const email = form.querySelector("#email").value.trim();
        const message = form.querySelector("#message").value.trim();

        form.style.display = "none";
        response.style.display = "flex";
        form.reset();
    });

    okBtn.addEventListener("click", () => {
        response.style.display = "none";
        form.style.display = "flex";
    });
})();

